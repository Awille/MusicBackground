create trigger update_time
  before INSERT
  on comment
  for each row
  BEGIN
	SET NEW.time = NOW();
	SET NEW.`like` = 0;
	SET NEW.dislike = 0;
END;

